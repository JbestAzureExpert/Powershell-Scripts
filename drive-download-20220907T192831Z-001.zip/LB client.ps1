﻿Clear-DnsClientCache 
nslookup LB-www.loadbalance.com
Resolve-DnsName LB-www.loadbalance.com
ipconfig /displaydns
